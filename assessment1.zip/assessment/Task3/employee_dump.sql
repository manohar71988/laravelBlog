-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: Employee
-- ------------------------------------------------------
-- Server version	5.7.25-0ubuntu0.16.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(255) NOT NULL,
  `ssn` varchar(200) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `is_curr_emp` tinyint(4) NOT NULL COMMENT '0 = No,1 = Yes',
  `email` varchar(320) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'John','123-45-6789','1986-07-25',1,'john@gmail.com','+372 799 2222','Harju County','2019-02-17 10:22:22','2019-02-17 10:22:22'),(2,'Vesper','987-65-4321','1990-04-15',1,'vesper@gmail.com','+372 899 4444','Tallin','2019-02-17 17:06:39','2019-02-17 17:12:28');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger `employee_logger` after insert on `employee`
for each row
begin
insert into employee_log(`user_name`,`timestamp`,`action`) values (USER(),NOW(),'Insert');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger `employee_update_logger` after update on `employee`
for each row
begin
insert into employee_log(`user_name`,`timestamp`,`action`) values (USER(),NOW(),'Update');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `employee_language`
--

DROP TABLE IF EXISTS `employee_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `emp_introduction` varchar(500) DEFAULT NULL,
  `emp_work_exp` varchar(500) DEFAULT NULL,
  `emp_education` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_emp` (`emp_id`),
  KEY `fk_lan` (`language_id`),
  CONSTRAINT `employee_language_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  CONSTRAINT `employee_language_ibfk_2` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_language`
--

LOCK TABLES `employee_language` WRITE;
/*!40000 ALTER TABLE `employee_language` DISABLE KEYS */;
INSERT INTO `employee_language` VALUES (1,1,1,'Hi,I\'m John. I\'m the new software engineer in the development team.I\'m excited to put my experience to work here!','Well, For the last three years I have been working in ABC Company as a software developer. In that position, I was responsible for handling all the development activities, from requirment gathering through to code refactor. I was also assigned to elevate development standards and meet clients’ expectations. During my tenure, I completed various professional training organized by the company.I was also awarded with different titles at my work.','2014,BS in Computer Science,University Of Houston, Houston, TX','2019-02-17 08:18:12','2019-02-17 08:18:12'),(2,1,2,'Hola soy john Soy el nuevo ingeniero de software en el equipo de desarrollo. ¡Estoy emocionado de poner mi experiencia aquí!','Bueno, durante los últimos tres años he estado trabajando en ABC Company como desarrollador de software. En esa posición, era responsable de manejar todas las actividades de desarrollo, desde la recopilación de requisitos hasta el refactor de código. También me encargaron elevar los estándares de desarrollo y cumplir con las expectativas de los clientes. Durante mi mandato, completé varias capacitaciones profesionales organizadas por la compañía. También obtuve diferentes títulos en mi trabajo.','2014, BS en Informática, University Of Houston, Houston, TX','2019-02-17 08:21:52','2019-02-17 08:21:52'),(3,1,3,'Bonjour, je suis John. Je suis le nouvel ingénieur logiciel de l\'équipe de développement. Je suis heureux de pouvoir mettre mon expérience à profit ici!','Depuis trois ans, je travaille chez ABC en tant que développeur de logiciels. À ce poste, j\'étais responsable de la gestion de toutes les activités de développement, de la collecte des exigences au refacteur de code. J\'étais également chargé d\'élever les normes de développement et de répondre aux attentes des clients. Au cours de mon mandat, j\'ai suivi diverses formations professionnelles organisées par l\'entreprise. De plus, différents titres m\'ont été décernés.','2014, BS en informatique,Université de Houston, Houston, TX','2019-02-17 08:23:44','2019-02-17 08:23:44'),(5,2,3,'Bonjour, je suis John. Je suis le nouvel ingénieur logiciel de l\'équipe de développement. Je suis heureux de pouvoir mettre mon expérience à profit ici!','Depuis trois ans, je travaille chez ABC en tant que développeur de logiciels. À ce poste, j\'étais responsable de la gestion de toutes les activités de développement, de la collecte des exigences au refacteur de code. J\'étais également chargé d\'élever les normes de développement et de répondre aux attentes des clients. Au cours de mon mandat, j\'ai suivi diverses formations professionnelles organisées par l\'entreprise. De plus, différents titres m\'ont été décernés.','2014, BS en informatique,Université de Houston, Houston, TX','2019-02-17 17:15:24','2019-02-17 17:15:24'),(6,2,2,'Hola soy john Soy el nuevo ingeniero de software en el equipo de desarrollo. ¡Estoy emocionado de poner mi experiencia aquí!','Bueno, durante los últimos tres años he estado trabajando en ABC Company como desarrollador de software. En esa posición, era responsable de manejar todas las actividades de desarrollo, desde la recopilación de requisitos hasta el refactor de código. También me encargaron elevar los estándares de desarrollo y cumplir con las expectativas de los clientes. Durante mi mandato, completé varias capacitaciones profesionales organizadas por la compañía. También obtuve diferentes títulos en mi trabajo.','2014, BS en Informática, University Of Houston, Houston, TX','2019-02-17 17:18:34','2019-02-17 17:25:35'),(7,2,1,'Hi,I\'m John. I\'m the new software engineer in the development team.I\'m excited to put my experience to work here!.','Well, For the last three years i have been working in ABC Company as a software developer. In that position, I was responsible for handling all the development activities, from requirment gathering through to code refactor. I was also assigned to elevate development standards and meet clients’ expectations. During my tenure, I completed various professional training organized by the company.I was also awarded with different titles at my work.','2014,BS in Computer Science,University Of Houston, Houston, TX','2019-02-17 17:19:29','2019-02-17 17:25:35');
/*!40000 ALTER TABLE `employee_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_log`
--

DROP TABLE IF EXISTS `employee_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_log`
--

LOCK TABLES `employee_log` WRITE;
/*!40000 ALTER TABLE `employee_log` DISABLE KEYS */;
INSERT INTO `employee_log` VALUES (1,'root@localhost','2019-02-17 17:06:39','Insert'),(2,'root@localhost','2019-02-17 17:12:28','Update');
/*!40000 ALTER TABLE `employee_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `language_id` (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES (1,1,'English','2019-02-17 07:40:25','2019-02-17 07:40:25'),(2,2,'Spanish','2019-02-17 07:40:40','2019-02-17 07:40:40'),(3,3,'French','2019-02-17 07:40:52','2019-02-17 07:40:52');
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-18  9:29:09
