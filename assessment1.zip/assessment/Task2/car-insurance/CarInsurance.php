<?php
require_once('Insurance.php');
require_once('DateTimeChecker.php');

class CarInsurance extends Insurance{
	private $estimatedCarValue;
	private $taxPercentage;
	private $installmentPaymentCount;
	private $dateTimeChecker;

	public function __construct(DateTimeChecker $dateTimeChecker = null){
		$this->estimatedCarValue = 0;
		$this->taxPercentage = 0;
		$this->installmentPaymentCount = 0;
		$this->dateTimeChecker = $dateTimeChecker;
	}

	public function setEstimatedCarValue($estimatedCarValue){

		$this->estimatedCarValue = $estimatedCarValue;
	}

	public function getEstimatedCarValue(){

		return $this->estimatedCarValue;
	}

	public function setTaxPercentage($taxPercentage){

		$this->taxPercentage = $taxPercentage;
	}

	public function getTaxPercentage(){

		return $this->taxPercentage;
	}

	public function setInstallmentPaymentCount($installmentPaymentCount){

		$this->installmentPaymentCount = $installmentPaymentCount;
	}

	public function getInstallmentPaymentCount(){

		return $this->installmentPaymentCount;
		
	}	

	public function calculatePolicyBasePayment(){
		$basePriceAmt = 0;		
		$currentDay = $this->dateTimeChecker->getCurrentDay();		
		 
		if($currentDay == 'Friday' && $this->dateTimeChecker->checkCurrentTime()){
			$basePriceAmt = (13 / 100) * $this->estimatedCarValue;
		}
		else{
			$basePriceAmt = (11 / 100) * $this->estimatedCarValue;
		}

		return (float)$basePriceAmt;
	}	

	public function calculatePolicyCost(){
		return $this->calculatePolicyBasePayment();
	}

	public function getBasePremiumPerInstallment(){ 
		$paymentArr = [];
		$installmentCount = $this->getInstallmentPaymentCount();
		$basePreAmount = $this->calculatePolicyBasePayment();		
		$tempCal = (float) bcdiv($basePreAmount,$installmentCount,2);
		$installmentPayment = (float)bcmul($tempCal,$installmentCount,2);	
		if($installmentPayment < $basePreAmount ){
			$tempAmt = $tempCal;
			$installmentCount -= 1;
			$installmentTempPayment =  $tempAmt * $installmentCount;
			$amtDiff = $basePreAmount - $installmentTempPayment;
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = $tempAmt;
			}
			$paymentArr[$i++] = $amtDiff;
		}
		else{
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = ($basePreAmount/$installmentCount) ;
			}
		}

		return $paymentArr;		
	}
}