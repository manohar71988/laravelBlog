<?php
require_once('InsuranceDecorator.php');
require_once('Insurance.php');

class Commission extends InsuranceDecorator{
	
	/** @var Insurance */
	private $insurance;
	
	public function __construct(Insurance $insurance){

		$this->insurance = $insurance;
	}


	public function calculatePolicyCost(){		

		return $this->insurance->calculatePolicyCost() + $this->applyCommission();

	}

	public function applyCommission(){
		$tempCost = 0;
		
		return (float)$tempCost = (17/100) * $this->insurance->calculatePolicyBasePayment();
	}
	
	public function getCost(){

		return $this->applyCommission();
	}

	public function getCommissionPerInstallment(){
		$paymentArr = [];
		$installmentCount = $this->getInstallmentPaymentCount();
		$commissionAmt = $this->applyCommission();

		//$tempCal = number_format(($commissionAmt/$installmentCount),2);
		//$tempCal = str_replace(",", "", $tempCal);
		//$tempCal = floatval($tempCal);		
		$tempCal = (float) bcdiv($commissionAmt,$installmentCount,2);
		$installmentPayment = (float)bcmul($tempCal,$installmentCount,2);
		if($installmentPayment < $commissionAmt ){
			$tempAmt = $tempCal;
			$installmentCount -= 1;
			$installmentTempPayment =  $tempAmt * $installmentCount;
			$amtDiff = $commissionAmt - $installmentTempPayment;
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = $tempAmt;
			}
			$paymentArr[$i++] = $amtDiff;
		}
		else{
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = $tempCal;
			}
		}

		return $paymentArr;
	}

	public function getOriginalObject(){
	    $object = $this->insurance;
	    while ($object instanceof InsuranceDecorator) {
	        $object = $object->getOriginalObject();
	    }
	    return $object;
	}

	public function __call($method, $args){	
	    if ($object = $this->isCallable($method)) {
	        return call_user_func_array(array($object, $method), $args);
	    }
	    throw new Exception(
	        'Undefined method - ' . get_class($this->getOriginalObject()) . '->' . $method
	    );
	}

	public function isCallable($method, $checkSelf = false){	   
	    $object = $this->getOriginalObject();
	    if (is_callable(array($object, $method))) {
	        return $object;
	    }
	    else	   
	    	return false;
	}

}