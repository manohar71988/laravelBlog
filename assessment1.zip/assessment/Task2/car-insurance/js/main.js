
(function ($) {
	//"use strict";
	
    

})(jQuery);