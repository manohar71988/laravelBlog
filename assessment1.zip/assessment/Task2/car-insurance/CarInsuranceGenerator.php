<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/> 


<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.12.4.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/jstimezonedetect/jstz.main.js"></script>

  
  <script src="vendor/bootstrap/js/popper.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
  <script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
  <script src="js/main.js"></script>


<script type = "text/javascript">
$(document).ready(function(){
	var tz = jstz.determine();
	//console.log(tz.name());
  setCookie("User-Time-Zone",tz.name(),1);
	var number = 0;
  $( "#slider-range-min" ).slider({
      range: "min",
      value: 100,
      min: 100,
      max: 100000,
      slide: function( event, ui ) {     
      	$("#car-amount").val(ui.value);
        $( "#amount" ).val( formatEuro(ui.value) );        
      }
   });
  var sliderVal = $( "#slider-range-min" ).slider( "value" );
  		$("#car-amount").val(sliderVal);
	$( "#amount" ).val( formatEuro(sliderVal));

  $( "#slider-tax_percent" ).slider({
      range: "min",
      value: 0,
      min: 0,
      max: 100,
      slide: function( event, ui ) {
      	$("#car-amount-tax").val(ui.value);
        $( "#percent" ).val( formatTax(ui.value) );
        
      }
    });
 	var percentVal = $( "#slider-tax_percent" ).slider( "value" );
  $("#car-amount-tax").val(percentVal);
	$( "#percent" ).val( formatTax(percentVal));

	$("#car-policy-form").submit(function(e) {
		    var form = $(this);
		    var url = form.attr('action');
		  	
		    $.ajax({
		           type: "POST",
		           url: url,
		           data: form.serialize(), // serializes the form's elements.
               beforeSend:function(){
                
               },
		           success: function(data)
		           {		               
		               $('#policy-output').html(data);
		           },
		         });

		    e.preventDefault(); // avoiding actual submit of the form.
	});
 
  $(document).on('mouseover','.column100',function(){
    var table1 = $(this).parent().parent().parent();
    var table2 = $(this).parent().parent();
    var verTable = $(table1).data('vertable')+"";
    var column = $(this).data('column') + "";

    $(table2).find("."+column).addClass('hov-column-'+ verTable);
    $(table1).find(".row100.head ."+column).addClass('hov-column-head-'+ verTable);
  });

  $(document).on('mouseout','.column100',function(){
    var table1 = $(this).parent().parent().parent();
    var table2 = $(this).parent().parent();
    var verTable = $(table1).data('vertable')+"";
    var column = $(this).data('column') + ""; 

    $(table2).find("."+column).removeClass('hov-column-'+ verTable);
    $(table1).find(".row100.head ."+column).removeClass('hov-column-head-'+ verTable);
  });

});
function formatEuro(val){
	return  val.toLocaleString('en-IN', { style: 'currency', currency: 'EUR' });
}
function formatTax(val){
	return val + " %"
}
function setCookie(name,value,days){
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
</script>
<style>
.body-font-css{
  font-family: arial;
  padding-left: 20px; padding-right: 20px;
  font-size: 15px;
}
.centered {  margin: 0 auto; width: 60%; }
.centered-policy-tbl {  margin: 0 auto; width: 40%; }
.policy-output-css {  margin: 0 auto; width: 80%; }

.btn-3d-sub {
  display: block;
  margin: 0 auto;
  width: 15%;
  height: 30px;
  font-family: Helvetica;
  border-bottom: 5px solid #8bdcee;
  border-top: none;
  border-left: none;
  border-right: none;
  background: linear-gradient(#d7dcde,#8bdcee);
  /*color: white;*/
  border-radius: 10px;
  box-shadow: 0px 2px 10px grey;
  transition: 150ms ease;
  text-align: center;
  line-height: 30px;
  font-weight: bold;
  cursor: pointer;
}
/*.device-fees-content-tble{	
  border-collapse:collapse;
 }  

.device-fees-content-tble tbody tr td{      
      font-size: 11px; font-family: "Arial";
      height: 50px;
      text-align: right;
      text-justify: inter-word; 
      min-width: 7em;   
      vertical-align: middle;
      border-collapse:collapse;
      border-style:solid; 
      border-width:1px; 
      border-color:#333333; 
      padding:6px;
 }

.device-fees-content-tble tbody tr td:first-child{    
      font-size: 11px; font-family: "Arial";
      height: 50px;
      text-align: right;
      text-justify: inter-word; 
      min-width: 8em;    
      vertical-align: middle;
      border-style:solid; 
      border-width:1px; 
      border-color:#333333; 
      padding:10px;
 }

 .device-fees-content-tble thead tr td{     
      font-size: 11px; font-family: "Arial";
      height: 50px;
      text-align: center;
      text-justify: inter-word; 
      min-width: 7em;      
      vertical-align: middle;
      font-weight: bold;
      border-style:solid; 
      border-width:1px; 
      border-color:#333333; 
      padding:6px;
      background-color: #e8eff3;
 }

 .device-fees-content-tble thead tr td:first-child{      
      font-size: 11px; font-family: "Arial";
      height: 50px;
      text-align: right;
      text-justify: inter-word; 
      min-width: 6em;      
      vertical-align: middle;    
      border-style:solid; 
      border-width:1px; 
      border-color:#333333; 
      padding:10px;
 }  */ 
</style>

<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

</head>
<body class = "body-font-css">
<form id = "car-policy-form"  action = "carInsuranceCalculator.php">
<div class="centered">
<center><span style = "font-weight: bold"> Car Insurance Calculator</span></center>
	<p>
	  <label for="amount">Estimated car value:</label>
	  <input  type="text" id="amount" readonly style="border:0; color:#5ac3da; font-weight:bold;" value = "">
	</p>
 
<div id="slider-range-min"></div>
<br>
<p>
	  <label for="percent">Tax Percentage:</label>
	  <input type="text" id="percent" readonly style="border:0; color:#5ac3da; font-weight:bold;" value = "">
	</p>
<div id="slider-tax_percent"></div>
<br>
<p>
    <label for="number">Select number of installments :- </label>
    <select name="installment-count" id="installment-count">
      <option selected="selected">1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
      <option>6</option>
      <option>7</option>
      <option>8</option>
      <option>9</option>
      <option>10</option>
      <option>11</option>
      <option>12</option>      
    </select>
 </p>
    <br>   
    <input type = "hidden" id = "car-amount" name = "car-amount" value = "" />
     <input type = "hidden" id = "car-amount-tax" name = "car-amount-tax" value = "" />
    <center><input type = "submit" class = "btn-3d-sub" name = "submit" id = "submit-car-policy" value = "Calculate"/></center>    
    </div>
  
   <div id = "loader"></div>

    <br>
    <SPAN id = "policy-output" class = "policy-output-css"></SPAN>
    
</form>
</body>
</html>