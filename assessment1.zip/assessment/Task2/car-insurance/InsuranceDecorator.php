<?php
require_once('Insurance.php');

abstract class InsuranceDecorator extends Insurance{
	
	abstract public function getCost();
}