<?php
public abstract class Insurance{
	
	public calculateBasePayment(){

	}

	public calculatePolicyCost();
}