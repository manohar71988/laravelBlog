<?php

interface TaxInterface{
	
	public applyBasePrice();

	public applyCommission();

	public applyTax();

}