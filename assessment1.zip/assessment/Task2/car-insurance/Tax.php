<?php
require_once('InsuranceDecorator.php');
require_once('Insurance.php');

class Tax extends InsuranceDecorator{
	
	/** @var Insurance */
	private $insurance;

	public function __construct(Insurance $insurance){

		$this->insurance = $insurance;
	}


	public function calculatePolicyCost(){

		 return $this->insurance->calculatePolicyCost() + $this->applyTax();
	}

	public function applyTax(){
		$tempCost = 0;

		return (float)$tempCost = ($this->insurance->getTaxPercentage()/100) * $this->insurance->calculatePolicyBasePayment();
	}

	public function getCost(){

		return $this->applyTax();
	}	

	public function getTaxPerInstallment(){

		//return $this->applyTax() / $this->insurance->getInstallmentPaymentCount();
		$paymentArr = [];
		$installmentCount = $this->getInstallmentPaymentCount();
		$taxAmt = $this->applyTax();				
		$tempCal = (float) bcdiv($taxAmt,$installmentCount,2);
		$installmentPayment = (float)bcmul($tempCal,$installmentCount,2);
		if($installmentPayment < $taxAmt ){
			$tempAmt = $tempCal;
			$installmentCount -= 1;
			$installmentTempPayment =  $tempAmt * $installmentCount;
			$amtDiff = $taxAmt - $installmentTempPayment;
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = $tempAmt;
			}
			$paymentArr[$i++] = $amtDiff;
		}
		else{
			for($i = 0; $i <= $installmentCount; $i++){
				$paymentArr[$i] = ($taxAmt/$installmentCount) ;
			}
		}

		return $paymentArr;
	}

	public function getOriginalObject(){
	    $object = $this->insurance;
	    while ($object instanceof InsuranceDecorator) {
	        $object = $object->getOriginalObject();
	    }
	    return $object;
	}

	public function __call($method, $args){	
	    if ($object = $this->isCallable($method)) {
	        return call_user_func_array(array($object, $method), $args);
	    }
	    throw new Exception(
	        'Undefined method - ' . get_class($this->getOriginalObject()) . '->' . $method
	    );
	}

	public function isCallable($method, $checkSelf = false){	    
	    $object = $this->getOriginalObject();
	    if (is_callable(array($object, $method))) {
	        return $object;
	    }
	    else   
	    	return false;
	}
}