<?php
require_once('Insurance.php');

abstract class InsuranceDecorator extends Insurance{

	//abstract public function calculatePolicyCost(); 

	//abstract public function calculatePolicyBasePayment();

	abstract public function applyCommission();
}