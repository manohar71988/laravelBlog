<?php
require_once('CarInsurance.php');
require_once('Insurance.php');
require_once('Commission.php');
require_once('Tax.php');
require_once('DateTimeChecker.php');

//error_reporting(1);
//ini_set('display_errors',1);

$carPrice = $taxPercent = $installmentCount = 0;$currentDateTimeAsUserTimeZone = '';$timeZone = ''; //Variable initialization
 try{ 	
	$userTimeZone = $_COOKIE["User-Time-Zone"];
	if(isset($userTimeZone) && !empty($userTimeZone)){
		$timeZone = $userTimeZone;
		
		$currDateTime = date("Y-m-d H:i:s", time() - date("Z")); //Getting UTC time
		$currentDateTimeAsUserTimeZone = convertDateFromTimezone($currDateTime,"UTC",$timeZone,'d-m-Y H:i:s');
	}
	else{
		 throw new Exception(
		        'Please check your time zone'
		    );
	}
	//Validating user inputs
	if(filter_var($_POST['car-amount'], FILTER_VALIDATE_INT, array("options" => array("min_range"=>100, "max_range"=>100000)))){
		$carPrice = $_POST['car-amount'];
	}
	else{	
		 throw new Exception(
		        'not valid car value'
		    );
	}

	if(filter_var($_POST['car-amount-tax'], FILTER_VALIDATE_INT, array("options" => array("min_range"=>0, "max_range"=>100)))){
		$taxPercent = $_POST['car-amount-tax'];
	}
	else{	
		 throw new Exception(
		        'not valid tax percent'
		    );
	}

	if(filter_var($_POST['installment-count'], FILTER_VALIDATE_INT, array("options" => array("min_range"=>1, "max_range"=>12)))){
		$installmentCount = $_POST['installment-count'];
	}
	else{	
		 throw new Exception(
		        'not valid count of installments'
		    );
	}
	//Validation done
	
	
	$dateTimeChecker = new DateTimeChecker();
	$dateTimeChecker->setTimeZone($timeZone);
	$dateTimeChecker->setDateTime($currentDateTimeAsUserTimeZone);

	//Decorator pattern used
	$carPolicyInsurance = new CarInsurance($dateTimeChecker);
	$carPolicyInsurance->setEstimatedCarValue($carPrice);
	$carPolicyInsurance->setTaxPercentage($taxPercent);
	$carPolicyInsurance->setInstallmentPaymentCount($installmentCount);		

	$policyBasePremium = $carPolicyInsurance->calculatePolicyBasePayment();
	$getBasePremiumPerInstallment = $carPolicyInsurance->getBasePremiumPerInstallment();
	
	$carInsuranceWithCommission = new Commission($carPolicyInsurance);
	$policyCommissionPerInstallment = $carInsuranceWithCommission->getCommissionPerInstallment();
	$policyCommission = $carInsuranceWithCommission->getCost();

	$carInsuranceWithTax = new Tax($carInsuranceWithCommission);
	$policyTaxPerInstallment = $carInsuranceWithTax->getTaxPerInstallment();
	$policyTax = $carInsuranceWithTax->getCost();

	$totalPolicyCost = $carInsuranceWithTax->calculatePolicyCost();
	
	//Pattern Completed
	
	
}
catch(Exception $e){

	echo $e->getMessage();
}

function convertDateFromTimezone($date,$timezone,$timezone_to,$format){
		 $date = new DateTime($date,new DateTimeZone($timezone));
		 $date->setTimezone( new DateTimeZone($timezone_to) );
		 return $date->format($format);
}
if(isset($_POST) && !empty($_POST)){
	$installmentHtml = '';
	$otherFormattingHtml = '';
	$columnCnt = 0;
	for($i = 1; $i<=$installmentCount; $i++){
		$columnCnt = $i + 2;
		$otherFormattingHtml .= "<td class='column100 column'".$columnCnt."'></td>";
		 $installmentHtml .= "<th class='column100 column".$columnCnt."' data-column='column".$columnCnt."'>".$i." Installment</th>";
		$basePremiumInstallment .= "<td class='column100 column".$columnCnt."' data-column='column".$columnCnt."'>".str_replace(",","",number_format($getBasePremiumPerInstallment[$i],2))."</td>";
		$commissionPerInstallment .= "<td class='column100 column".$columnCnt."' data-column='column".$columnCnt."'>".str_replace(",","",number_format($policyCommissionPerInstallment[$i],2))."</td>";
		$taxPerInstallment .= "<td class='column100 column".$columnCnt."' data-column='column".$columnCnt."'>".str_replace(",","",number_format($policyTaxPerInstallment[$i],2))."</td>";
		$totalCostPerInstallment = $getBasePremiumPerInstallment[$i] + $policyCommissionPerInstallment[$i] + $policyTaxPerInstallment[$i];
		$totalCostPerInstallment = number_format($totalCostPerInstallment,2);
		$finalTotalCostPerInstallment = str_replace ( ",","", $totalCostPerInstallment);
		$totalInstallmentCost .= "<td class='column100 column".$columnCnt."' data-column='column".$columnCnt."'>".$finalTotalCostPerInstallment."</td>";
	}

	$carPrice = number_format($carPrice,2);
	$finalCarPrice = str_replace ( ",","", $carPrice);
	$policyBasePremium = number_format($policyBasePremium,2);
	$finalPolicyBasePremium = str_replace ( ",","", $policyBasePremium);
	$policyCommission = number_format($policyCommission,2);
	$finalPolicyCommission = str_replace ( ",","", $policyCommission);
	$policyTax = number_format($policyTax,2);
	$finalPolicyTax = str_replace ( ",","", $policyTax);
	$totalPolicyCost = number_format($totalPolicyCost,2);
	$finalTotalPolicyCost = str_replace ( ",","", $totalPolicyCost);
?>	

<div class="wrap-table100">
 <div class="table100 ver5 m-b-110">
          <table data-vertable="ver5">            
            <thead><tr class="row100 head">
					<th class="column100 column1" data-column="column1"></th>
					<th class="column100 column2" data-column="column2">Policy</th>
					<?php echo $installmentHtml;?>
					</tr>
			</thead>
				 	<tbody>
              			<tr class="row100 head">
              			<td class="column100 column1" data-column="column1">Value</td>
              			<td class="column100 column2" data-column="column2"><?php echo $finalCarPrice; ?></td>
              			<?php echo $otherFormattingHtml;?>
              			</tr>
              			<tr class="row100 head">
              			<td class="column100 column1" data-column="column1">Base Premium(11%)</td>
              			<td class="column100 column2" data-column="column2"><?php echo $finalPolicyBasePremium;?></td>
              			<?php echo $basePremiumInstallment; ?>
              			</tr>
              			<tr class="row100 head">
						<td class="column100 column1" data-column="column1">Commission(17%)</td>
						<td class="column100 column2" data-column="column2"><?php echo $finalPolicyCommission;?></td>
						<?php echo $commissionPerInstallment;?>
						</tr>
						<tr class="row100 head">
						<td class="column100 column1" data-column="column1">Tax(10%)</td>
						<td class="column100 column2" data-column="column2"><?php echo $finalPolicyTax; ?></td>
						<?php echo $taxPerInstallment;?>
						</tr>
						<tr class="row100 head">
						<td class="column100 column1" data-column="column1"><b>Total Cost</b></td>
						<td class="column100 column2" data-column="column2"><font color = "red"><?php echo $finalTotalPolicyCost; ?>
							
						</font></td> <?php echo $totalInstallmentCost; ?>
						</tr>
          			</tbody>
            </thead>
    	  </table>
   </div>
</div>

<?php
}
?>

