<?php
class DateTimeChecker{

	private $timeZone;
	private $dateTime;

	public function __construct(){
		$this->timeZone = '';
		$this->dateTime = '';
	}

	public function setTimeZone($timeZone){

		$this->timeZone = $timeZone;
	}

	public function getTimeZone(){

		return $this->timeZone ;
	}

	public function setDateTime($dateTime){
		
		$this->dateTime = $dateTime;
	}

	public function getDateTime(){

		return $this->dateTime;
	}

	public function getCurrentDay(){

		return $dayName = date("l",strtotime($this->getDateTime()));
	}

	public function checkCurrentTime(){
		$curUserDateTime = new DateTime($this->getDateTime());
		$tempDate1 = date('d-m-Y 15:00:00',strtotime($this->getDateTime())); 
		$tempDate2 = date('d-m-Y 20:00:00',strtotime($this->getDateTime())); 
		$startDateTime = new DateTime($tempDate1);
		$endDateTime = new DateTime($tempDate2);	
	  	
		if($curUserDateTime >= $startDateTime && $curUserDateTime <= $endDateTime)		
		   return true;		
		else 
		   return false;
	}
}