<?php
//namespace Insurance;

abstract class Insurance{

	abstract public function calculatePolicyCost();
}