<?php
require_once('Insurance.php');

public abstract class taxDecorator extends Insurance{

	//abstract public  function calculatePolicyCost(); 

	abstract public function applyTax();
}