<?php

class CarInsurance{
	private $estimatedCarValue;
	private $taxPercentage;
	private $installmentPaymentCount;

	public function setEstimatedCarValue(){

	}

	public function getEstimatedCarValue(){

	}

	public function setTaxPercentage(){

	}

	public function getTaxPercentage(){

	}

	public function setInstallmentPaymentCount(){

	}

	public function getInstallmentPaymentCount(){
		
	}
}