<?php
$binaryStr = "01110000 01110010 01101001 01101110 01110100 00100000 01101111 01110101 01110100 00100000 01111001 01101111 01110101 01110010 00100000 01101110 01100001 01101101 01100101 00100000 01110111 01101001 01110100 01101000 00100000 01101111 01101110 01100101 00100000 01101111 01100110 00100000 01110000 01101000 01110000 00100000 01101100 01101111 01101111 01110000 01110011";

convertBinaryToHumanReadable($binaryStr);

function convertBinaryToHumanReadable($binaryStr){
$bitsArr = explode(" ",$binaryStr);
	foreach($bitsArr as $key => $byteVal){
		$bin = $byteVal; $decimal = 0; $i = 1; $decimal = 0;
		while($bin != 0){	
			$remainder = 0; 
			
			$remainder = $bin % 10; 
		  	$bin = intval($bin/10);  	
		  
		    $decimal += $remainder * $i;
		    $i *= 2;

		}	
	 	echo chr($decimal);	 
	}
}



